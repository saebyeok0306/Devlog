package io.blog.mail

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class MailserverApplicationTests {

	@Test
	fun contextLoads() {
	}

}
